package opdrachten;

import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.List;
import java.util.Collections;

public class Versleutelenfinal {

	public static void main(String[] args) {
//	Een random, een scanner en string worden aangemaakt.
		String shuffledMessage = "";
		Random randomPosition = new Random();
		Scanner input = new Scanner(System.in);

//	De gebruiker wordt gevraagd een bericht in te voeren en het bericht wordt opgeslagen.
		System.out.println("Type the message you want to send and press enter: ");
		String userInput = input.nextLine();
		char[] message = userInput.toCharArray();

//	Alle opties waar een random code van gemaakt moet worden.
		char[] options = { ' ', '.', ',', '!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '_', '=', '+', '<',
				'>', '/', '?', '|', '€', '`', '~', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'a', 'á', 'à', 'ã',
				'ä', 'b', 'c', 'ç', 'd', 'e', 'é', 'ë', 'è', 'f', 'g', 'h', 'i', 'í', 'ï', 'ì', 'j', 'k', 'l', 'm', 'n',
				'ñ', 'o', 'ó', 'ö', 'ò', 'õ', 'p', 'q', 'r', 's', 't', 'u', 'ú', 'ü', 'ù', 'v', 'w', 'x', 'y', 'ý', 'ÿ',
				'z', 'A', 'Á', 'Ä', 'À', 'Ã', 'B', 'C', 'Ç', 'D', 'E', 'É', 'Ë', 'È', 'F', 'G', 'H', 'I', 'Í', 'Ï', 'Ì',
				'J', 'K', 'L', 'M', 'N', 'Ñ', 'O', 'Ó', 'Ö', 'Ò', 'Õ', 'P', 'Q', 'R', 'S', 'T', 'U', 'Ú', 'Ü', 'Ù', 'V',
				'W', 'X', 'Y', 'Ý', 'Z', };

//	Het aanmaken van de random code waarbij de options array wordt gehusseld.
//	Een arrayList genaamt optionList maken.
		List<Character> optionsList = new ArrayList<>();
		
//	De arrayList (options) shuffelen met de .shuffle en randomPosition functie en toevoegen aan optionList.
		for (char c : options)
			optionsList.add(c);
		Collections.shuffle(optionsList, randomPosition);
		
//	De charArray (shuffledOptions) aanmaken.
		char[] shuffledOptions = new char[options.length];
		
//	De arrayList (optionsList) in de charArray (shuffledOptions) doen.
		for (int i = 0; i < options.length; i++) {
			shuffledOptions[i] = optionsList.get(i);
		}

//	De random code maakt het bericht versleuteld
		for (int i = 0; i < message.length; i++) {
			
//	Zo vaak loopen als dat de charArray (options) lang is.
			for (int k = 0; k < options.length; k++) {
				
//	Als de juiste letter is gevonden in de charArray (options) diezelfden index waarden van de charArray (shuffledOptions) toevoegen aan het versleutelden bericht. 
				if (message[i] == options[k]) {
					shuffledMessage = shuffledMessage + shuffledOptions[k];
				}
			}

		}
		System.out.println(shuffledMessage);

//	Het bericht wordt ontsleuteld als de gebruiker dat wilt
		System.out.println("Would you like to receive the unobfuscated message? Type yes or no and press enter: ");
		userInput = input.nextLine();
		if (userInput.equals("yes")) {
			String translated = "";
			
//	het versleutelde bericht veranderen naar een charArray genaamt (shuffledMessageArray).
			char[] shuffledMessageArray = shuffledMessage.toCharArray();

			for (int i = 0; i < shuffledMessageArray.length; i++) {
//	Zo vaak loopen als dat de charArray (options) lang is.
				for (int k = 0; k < options.length; k++) {
					
//	Als de juiste letter is gevonden in de charArray (shuffledOptions) diezelfden index waarden van de charArray (options) toevoegen aan het ontsleutelden bericht. 
					if (shuffledMessageArray[i] == shuffledOptions[k]) {
						translated = translated + options[k];
					}
				}
			}
			System.out.println(translated);
		}

	}

}
